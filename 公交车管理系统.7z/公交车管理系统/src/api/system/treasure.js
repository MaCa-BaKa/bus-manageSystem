import request from '@/utils/request'

// 查询宝物信息列表
export function listTreasure(query) {
  return request({
    url: '/system/treasure/list',
    method: 'get',
    params: query
  })
}

// 查询宝物信息详细
export function getTreasure(trId) {
  return request({
    url: '/system/treasure/' + trId,
    method: 'get'
  })
}

// 新增宝物信息
export function addTreasure(data) {
  return request({
    url: '/system/treasure',
    method: 'post',
    data: data
  })
}

// 修改宝物信息
export function updateTreasure(data) {
  return request({
    url: '/system/treasure',
    method: 'put',
    data: data
  })
}

// 删除宝物信息
export function delTreasure(trId) {
  return request({
    url: '/system/treasure/' + trId,
    method: 'delete'
  })
}
