import request from '@/utils/request'

// 查询设施管理列表
export function listFacility(query) {
  return request({
    url: '/system/facility/list',
    method: 'get',
    params: query
  })
}

// 查询设施管理详细
export function getFacility(sId) {
  return request({
    url: '/system/facility/' + sId,
    method: 'get'
  })
}

// 新增设施管理
export function addFacility(data) {
  return request({
    url: '/system/facility',
    method: 'post',
    data: data
  })
}

// 修改设施管理
export function updateFacility(data) {
  return request({
    url: '/system/facility',
    method: 'put',
    data: data
  })
}

// 删除设施管理
export function delFacility(sId) {
  return request({
    url: '/system/facility/' + sId,
    method: 'delete'
  })
}
