import request from '@/utils/request'

// 查询宝物和人物关系表列表
export function listKeyman_1(query) {
  return request({
    url: '/system/keyman_1/list',
    method: 'get',
    params: query
  })
}

// 查询宝物和人物关系表详细
export function getKeyman_1(id) {
  return request({
    url: '/system/keyman_1/' + id,
    method: 'get'
  })
}

// 新增宝物和人物关系表
export function addKeyman_1(data) {
  return request({
    url: '/system/keyman_1',
    method: 'post',
    data: data
  })
}

// 修改宝物和人物关系表
export function updateKeyman_1(data) {
  return request({
    url: '/system/keyman_1',
    method: 'put',
    data: data
  })
}

// 删除宝物和人物关系表
export function delKeyman_1(id) {
  return request({
    url: '/system/keyman_1/' + id,
    method: 'delete'
  })
}
